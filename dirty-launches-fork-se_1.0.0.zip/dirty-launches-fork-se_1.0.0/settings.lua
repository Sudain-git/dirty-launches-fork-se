data:extend({
    {
        type = "int-setting",
        name = "dl-fork-se-pollution",
        setting_type = "runtime-global",
        default_value = 10000,
        minimum_value = 0,
        maximum_value = 1000000,
        order = "a"
    },
    {
        type = "string-setting",
        name = "dl-fork-se-cargo-mode",
        setting_type = "runtime-global",
        default_value = "dynamic",          -- changed: dynamic is the useful default
        allowed_values = {"default", "dynamic"},
        order = "b"
    },
    {
        type = "int-setting",
        name = "dl-fork-se-cargo-pollution",
        setting_type = "runtime-global",
        default_value = 10000,              -- changed: match standard rocket default
        minimum_value = 0,
        maximum_value = 1000000,
        order = "c"
    },
})

data:extend({{
    type = "double-setting",
    name = "dl-fork-se-cargo-scalar",
    setting_type = "runtime-global",
    default_value = 1.0,
    minimum_value = 0.0,
    maximum_value = 10.0,
    order = "d"
}})
