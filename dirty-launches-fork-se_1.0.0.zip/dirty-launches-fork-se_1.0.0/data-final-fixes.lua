-- SE's postprocess uses cascade=true on several base-game technologies, which
-- recursively adds science packs AND prerequisites to any technology in their
-- prerequisite chain -- including ours.
-- This file runs after space-exploration-postprocess (see info.json dependency)
-- and resets our techs to exactly what we intend.

if not mods["space-exploration"] then return end

local intended_packs = {
    {"automation-science-pack",  1},
    {"logistic-science-pack",    1},
    {"chemical-science-pack",    1},
    {"se-rocket-science-pack",   1},
    {"space-science-pack",       1},
}

local intended_counts = {100, 400, 900, 1600, 2500, 3600, 4900, 6400, 8100, 10000}

for i = 1, 10 do
    local tech = data.raw.technology["cleaner-rocket-exhaust-" .. i]
    if tech then
        -- Reset science packs (SE cascade injects production, material-4, deep-space-1, etc.)
        if tech.unit then
            tech.unit.ingredients = intended_packs
            tech.unit.count = intended_counts[i]
        end
        -- Reset prerequisites (SE cascade may also inject extra tech requirements)
        -- Each level gates only on the previous level; level 1 gates on getting into space.
        if i == 1 then
            tech.prerequisites = {"se-rocket-science-pack"}
        else
            tech.prerequisites = {"cleaner-rocket-exhaust-" .. (i - 1)}
        end
    end
end
