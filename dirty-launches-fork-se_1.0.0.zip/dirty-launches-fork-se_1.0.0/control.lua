-- Returns the highest researched Cleaner Rocket Exhaust level for a force (0 if none).
local function get_cleaning_level(force)
    for i = 10, 1, -1 do
        local tech = force.technologies["cleaner-rocket-exhaust-" .. i]
        if tech and tech.researched then
            return i
        end
    end
    return 0
end

-- Standard rocket launch: fixed base pollution reduced by tech level.
-- Each level cuts 10%, so level 10 = 0% pollution.
script.on_event(defines.events.on_rocket_launched, function(event)
    local silo = event.rocket_silo
    if not (silo and silo.valid) then return end

    local base_pollution  = settings.global["dl-fork-se-pollution"].value
    local level           = get_cleaning_level(silo.force)
    local multiplier      = 1 - (level * 0.1)
    local final_pollution = base_pollution * multiplier

    silo.surface.pollute(silo.position, final_pollution)
end)

-- SE cargo rocket handler.
-- remote.call is only allowed inside an event, so we can't call it in the main
-- chunk. We register the cargo event inside on_init (new game) and on_load
-- (every subsequent load), which are both valid event contexts.
local function register_cargo_event()
    if not script.active_mods["space-exploration"] then return end

    local cargo_event_id = remote.call("space-exploration", "get_on_cargo_rocket_launched_event")

    script.on_event(cargo_event_id, function(event)
        if not (event.launchpad and event.launchpad.valid) then return end

        local force      = game.forces[event.force_name]
        local level      = get_cleaning_level(force)
        local multiplier = 1 - (level * 0.1)
        local mode       = settings.global["dl-fork-se-cargo-mode"].value
        local base       = settings.global["dl-fork-se-cargo-pollution"].value

        if mode == "dynamic" then
            -- Count inventory slots used from the launched contents.
            -- SE doesn't expose required_fuel in the event payload, so we mirror
            -- SE's own internal scaling: rocket_cost_p = 0.5 + 0.5 * fullness.
            --   empty rocket = 50% of base,  full rocket = 100% of base.
            local slots_used = 0
            if event.launched_contents then
                for _, item in pairs(event.launched_contents) do
                    local proto = prototypes.item[item.name]
                    if proto then
                        slots_used = slots_used + math.ceil(item.count / proto.stack_size)
                    end
                end
            end
            local cargo_fraction = math.min(slots_used / 500, 1.0)
            local scalar = settings.global["dl-fork-se-cargo-scalar"].value
            base = base * (0.5 + scalar * cargo_fraction)
        end

        local final_pollution = base * multiplier
        event.launchpad.surface.pollute(event.launchpad.position, final_pollution)
    end)
end

script.on_init(register_cargo_event)
script.on_load(register_cargo_event)
