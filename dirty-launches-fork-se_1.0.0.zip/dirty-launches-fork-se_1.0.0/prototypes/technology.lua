local is_se = mods["space-exploration"]

local science_packs
if is_se then
    science_packs = {
        {"automation-science-pack",  1},
        {"logistic-science-pack",    1},
        {"chemical-science-pack",    1},
        {"se-rocket-science-pack",   1},
        {"space-science-pack",       1},
    }
else
    science_packs = {
        {"automation-science-pack",  1},
        {"logistic-science-pack",    1},
        {"chemical-science-pack",    1},
        {"space-science-pack",       1},
    }
end

-- 10 levels, each reducing pollution by 10%.
-- Research cost = level^2 * 100  (100, 400, 900 ... 10000)
-- NOTE: upgrade = true is intentionally omitted. These are 10 distinct named techs,
-- not an infinite chain, and upgrade=true causes SE's postprocess to cascade
-- unwanted science packs into our requirements.
for i = 1, 10 do
    local before_percent = 100 - ((i - 1) * 10)
    local after_percent  = 100 - (i * 10)

    local prerequisites
    if i == 1 then
        if is_se then
            prerequisites = {"se-rocket-science-pack"}
        else
            prerequisites = {"rocket-silo"}
        end
    else
        prerequisites = {"cleaner-rocket-exhaust-" .. (i - 1)}
    end

    data:extend({{
        type = "technology",
        name = "cleaner-rocket-exhaust-" .. i,
        icon = "__dirty-launches-fork-se__/graphics/technology/cleaner-rocket-exhaust-" .. i .. ".png",
        icon_size = 128,
        prerequisites = prerequisites,
        effects = {{
            type = "nothing",
            effect_description = "Pollution burst on launch: " .. before_percent .. "% → " .. after_percent .. "%",
            icon = "__base__/graphics/icons/rocket-part.png",
            icon_size = 64
        }},
        unit = {
            count = i * i * 100,
            ingredients = science_packs,
            time = 30
        },
        order = "k-a[" .. string.format("%02d", i) .. "]"
    }})
end
